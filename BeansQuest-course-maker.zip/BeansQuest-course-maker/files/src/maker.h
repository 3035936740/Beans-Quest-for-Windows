#pragma once

// Course maker integration. The maker chapter appears as a seventh World Select card once the
// Wizard is defeated (or SKELETONKEY is entered). Custom courses run through the campaign stage
// runtime; leaving them returns to the editor (test play) or to the course list.
#include "maker_ui.h"
#include "maker_data.h"
#include "maker_catalog.h"
#include "maker_bake.h"
#include "maker_editor.h"
#include "maker_browser.h"

const u64 MAKER_WORLD_NODE = 0x4d414b4552ULL; // "MAKER"
MakerLevel *makerPlayLevel;
bool makerPlayFromCursor, makerJustVerified;
Vec makerPlayStart;
int makerCourseCount;
int makerTestClearJumps; // jumps of the last test clear, -1 while the test has not been cleared

bool makerScreen() {
    return screen == MAKER_EDIT || screen == MAKER_BROWSE;
}

void makerLoadCurrentLevel() {
    if (!makerPlayLevel) {
        makerRun.active = false;
        loadLevelData(levels[stageList[currentStage]].file);
        return;
    }
    makerBakeCourse(*makerPlayLevel, makerRun.slot, current, levelArena,
                    makerPlayFromCursor ? &makerPlayStart : 0);
}

// currentStage keeps the campaign position; startStage consults makerRun to bake the course.
void makerStartRun(MakerLevel &level, int slot, bool testing, bool fromCursor, Vec start) {
    makerPlayLevel = &level;
    makerRun.active = true;
    makerRun.testing = testing;
    makerRun.verifying = testing && !fromCursor;
    makerRun.slot = slot;
    makerRun.recordJumps = !testing && level.head.cleared ? level.head.bestJumps : 0;
    makerPlayFromCursor = fromCursor;
    makerPlayStart = start;
    makerJustVerified = false;
    makerTestClearJumps = -1;
    worldSelectPointerNative = WorldSelectPointerNative{};
    pointerHeld = false;
    pointerNode = -1;
    stopSounds();
    startStage(currentStage, false);
    if (testing) {
        // Test runs start at once; course runs keep the READY banner with the course name.
        readyOpening = readyNativeInitial(true);
        readyTimer = 0;
    }
    transitionTime = transitionDuration = 0.3f;
}

void makerStartTest(bool fromCursor) {
    if (fromCursor && !edInCanvas(makerEd.mouseX, makerEd.mouseY))
        fromCursor = false;
    float wx = edWorldX(makerEd.mouseX), wy = edWorldY(makerEd.mouseY);
    Vec start = {edSnapCoord(wx, 32) + 16, edSnapCoord(wy, 32) + 16};
    makerEd.drag = DRAG_NONE;
    makerEd.picker = makerEd.settings = makerEd.help = makerEd.nameEditing = false;
    makerStartRun(makerEd.level, makerEd.slot, true, fromCursor, start);
}

void makerStartCourse(int slot) {
    makerAllocate(makerPlayCourse);
    if (!makerLoadLevel(slot, makerPlayCourse)) {
        mkToast("This course could not be loaded", 0xff8080ff);
        return;
    }
    makerProfile.lastSlot = slot;
    makerWriteProfile();
    makerStartRun(makerPlayCourse, slot, false, false, Vec{0, 0});
}

void makerEditCourse(int slot, bool fresh, int theme) {
    if (!edOpen(slot, fresh, theme)) {
        mkToast("This course could not be loaded", 0xff8080ff);
        return;
    }
    makerProfile.lastSlot = slot;
    makerWriteProfile();
    if (fresh) {
        makerSaveLevel(slot, makerEd.level);
        makerEd.dirty = false;
    }
    screen = MAKER_EDIT;
    transitionTime = transitionDuration = 0.25f;
    playMusic(makerCourseMusic(makerEd.level.head));
}

void makerOpenBrowser() {
    makerRun.active = false;
    makerEd.open = false;
    resetPauseInterfaceNative();
    respawnCancel(respawnTransition);
    deathTimer = deathAge = 0;
    resetEndingScene();
    pointerHeld = false;
    pointerNode = -1;
    makerReadProfile();
    if (!makerProfile.seen) {
        makerProfile.seen = 1;
        makerWriteProfile();
    }
    brOpen();
    screen = MAKER_BROWSE;
    transitionTime = transitionDuration = 0.25f;
    playMusic(3080012186760326ULL);
}

void makerFocusWorldCard() {
    for (int i = 0; i < page.level.objectCount; i++)
        if (page.nodes[i].object->id == MAKER_WORLD_NODE) {
            page.focus = i;
            selectedWorld = 7;
            page.cameraX = page.targetX = center(page.nodes[i].rect).x - viewW * 0.5f;
            return;
        }
}

void makerLeaveBrowser() {
    makerWriteProfile();
    navigate(18006219643615701355ULL);
    makerFocusWorldCard();
    transitionTime = transitionDuration = 0.25f;
}

void makerExitPlay() {
    bool testing = makerRun.testing, verifying = makerRun.verifying;
    makerRun.active = false;
    resetPauseInterfaceNative();
    respawnCancel(respawnTransition);
    deathTimer = deathAge = 0;
    resetEndingScene();
    stopSounds();
    clearEffects();
    complete = false;
    readyTimer = 0;
    pointerHeld = false;
    pointerNode = -1;
    if (testing && makerEd.open) {
        screen = MAKER_EDIT;
        transitionTime = transitionDuration = 0.25f;
        playMusic(makerCourseMusic(makerEd.level.head));
        char text[96];
        if (makerTestClearJumps >= 0) {
            if (!verifying)
                lstrcpyA(text, "Cleared from the cursor - test from the start to verify");
            else
                wsprintfA(text, "%sCleared in %d jumps (gold shoe: %d)",
                          makerJustVerified ? "Course verified! " : "", makerTestClearJumps,
                          makerEd.level.head.jumpBest);
            mkToast(text, 0x80ff80ff, 4);
        }
        makerJustVerified = false;
    } else
        makerOpenBrowser();
}

// Clears from the course start verify a course under test; real runs keep their records.
void makerRecordClear() {
    if (!makerPlayLevel)
        return;
    MakerHeader &h = makerPlayLevel->head;
    if (makerRun.testing) {
        makerTestClearJumps = jumps;
        if (makerRun.verifying && !(h.flags & MAKER_VERIFIED)) {
            h.flags |= MAKER_VERIFIED;
            makerEd.dirty = true;
            makerJustVerified = true;
        }
        return;
    }
    h.cleared = 1;
    if (!h.bestJumps || jumps < h.bestJumps)
        h.bestJumps = jumps;
    if (coins > h.bestCoins)
        h.bestCoins = coins;
    if (salamander)
        h.axolotl = 1;
    makerRun.recordJumps = h.bestJumps;
    makerSaveLevel(makerRun.slot, *makerPlayLevel);
}

bool makerHudCaption(u64 id, char *value) {
    if (!makerRun.active)
        return false;
    if (id == 11477711412535822434ULL) {
        if (makerRun.testing)
            lstrcpyA(value, "TEST PLAY");
        else
            wsprintfA(value, "COURSE C-%02d", makerRun.slot + 1);
        return true;
    }
    if (id == 8364913218960181251ULL) {
        int par = (int)current.props.num("bean-jump-par");
        lstrcpyA(value, makerRun.recordJumps && makerRun.recordJumps <= par ? "BEST" : "PAR");
        return true;
    }
    return false;
}

int makerCountCourses() {
    int n = 0;
    for (int i = 0; i < MAKER_SLOTS; i++) {
        char path[MAX_PATH];
        makerCoursePath(i, path);
        n += GetFileAttributesA(path) != INVALID_FILE_ATTRIBUTES;
    }
    return n;
}

// Append the maker card after the Wizard's slot. Nodes are rebuilt in the scene arena so the
// authored objects keep their order and the new card behaves like any world button.
void makerDecorateWorldSelect() {
    worldSelectSlots = 6;
    if (!makerUnlocked())
        return;
    UiScene &s = page;
    int boss = -1;
    for (int i = 0; i < s.level.objectCount; i++) {
        if (s.level.objects[i].id == MAKER_WORLD_NODE)
            return;
        if (s.level.objects[i].has("WorldLevelButtonBehaviour"))
            boss = i;
    }
    if (boss < 0)
        return;
    int n = s.level.objectCount;
    Object *objects = s.memory.array<Object>(n + 1);
    memcpy(objects, s.level.objects, sizeof(Object) * n);
    UiNode *nodes = s.memory.array<UiNode>(n + 1);
    memcpy(nodes, s.nodes, sizeof(UiNode) * n);
    for (int i = 0; i < n; i++)
        nodes[i].object = objects + i;
    Object &bossObject = objects[boss];
    char bossId[24], makerId[24];
    idstr(bossObject.id, bossId);
    idstr(MAKER_WORLD_NODE, makerId);
    Props *bossProps = makerBehaviorProps(bossObject, "WorldLevelButtonBehaviour");
    if (bossProps)
        makerSetProp(*bossProps, "focus-right", makerId, s.memory);
    Object &o = objects[n];
    o = bossObject;
    o.id = MAKER_WORLD_NODE;
    Vec c = center(bossObject.rect);
    o.rect = makerCentered(c.x + 224, c.y, 160, 160);
    o.behaviors = s.memory.array<Behavior>(1);
    o.behaviorCount = 1;
    o.behaviors[0].type = makerString(s.memory, "WorldButtonBehaviour");
    Props p = {};
    makerSetProp(p, "world", "7", s.memory);
    makerSetProp(p, "level", "0", s.memory);
    makerSetProp(p, "focus-left", bossId, s.memory);
    makerSetProp(p, "focus-up", "17649694756044529744", s.memory); // the authored Back button
    o.behaviors[0].props = p;
    UiNode &node = nodes[n];
    memset(&node, 0, sizeof(node));
    node.object = &o;
    node.rect = o.rect;
    node.stage = -1;
    node.world = 7;
    s.level.objects = objects;
    s.nodes = nodes;
    s.level.objectCount = n + 1;
    // Particle pools are keyed by object address; rebind them as loadUi does.
    nativeContinuousResetScene(s.level);
    nativeContinuousAdvanceScene(s.level, 1, 0, 0);
    worldSelectSlots = 7;
    makerCourseCount = makerCountCourses();
}

bool makerWorldNode(const Object &o) {
    return o.id == MAKER_WORLD_NODE;
}

// The maker card mirrors the authored cards: a framed scene, a title and a courses caption.
bool makerDrawWorldNode(UiScene &s, UiNode &n) {
    if (&s != &page || !n.object || n.object->id != MAKER_WORLD_NODE)
        return false;
    Vec c = center(n.rect);
    float half = 96, l = c.x - half, b = c.y - half;
    mkRect(l + 4, b - 4, 192, 192, 0x00000070);
    mkGradient(l, b, 192, 192, 0xa86a10ff, 0xffe070ff);
    mkGradient(l + 8, b + 8, 176, 176, 0x2c5d8cff, 0x8fd0f8ff);
    glDisable(GL_TEXTURE_2D);
    glColor4f(1, 1, 1, 0.12f);
    glBegin(GL_LINES);
    for (float x = l + 8; x <= l + 184; x += 22) {
        glVertex2f(x, b + 8);
        glVertex2f(x, b + 184);
    }
    for (float y = b + 8; y <= b + 184; y += 22) {
        glVertex2f(l + 8, y);
        glVertex2f(l + 184, y);
    }
    glEnd();
    mkRect(l + 8, b + 8, 176, 34, 0x6b4a2cff);
    mkRect(l + 8, b + 38, 176, 6, 0x63b33fff);
    Object *beanClass = makerClass(MAKER_CLASS_BEAN), *gemClass = makerClass(MAKER_CLASS_DIAMOND);
    Object *goalClass = makerClass(MAKER_CLASS_GOAL);
    Actor *bean = actor(MAKER_CLASS_BEAN), *gem = actor(MAKER_CLASS_DIAMOND),
          *goal = actor(MAKER_CLASS_GOAL);
    float bounce = absf(bqSin(s.age * 3.2f)) * 46;
    drawActor(goal, makerCentered(c.x + 52, b + 44 + 40, 64, 80), edAnimation(goal, goalClass),
              s.age);
    for (int i = 0; i < 3; i++)
        drawActor(gem, makerCentered(c.x - 40 + i * 26, c.y + 44, 24, 24),
                  edAnimation(gem, gemClass), s.age + i * 0.2f);
    drawActor(bean, makerCentered(c.x - 30, b + 60 + bounce, 32, 32), edAnimation(bean, beanClass),
              s.age);
    if (n.disabled)
        mkRect(l + 8, b + 8, 176, 176, 0x00000090);
    const char *title = "MAKER";
    float tw = mkTextWidth(title, 22, true);
    mkText(c.x - tw * 0.5f + 2, b + 194 - 2, title, 22, 0x5a2d00ff, true);
    mkText(c.x - tw * 0.5f, b + 194, title, 22, 0xffd84aff, true);
    char caption[32];
    wsprintfA(caption, "%d course%s", makerCourseCount, makerCourseCount == 1 ? "" : "s");
    mkTextCentered(c.x, b - 10, caption, 9, 0xffffffff, true);
    makerReadProfile();
    if (!makerProfile.seen && ((int)(s.age * 3) & 1))
        mkTextShadow(l + 120, b + 160, "NEW!", 12, 0xff5050ff, true);
    return true;
}

bool makerKey(int key) {
    if (screen == MAKER_EDIT)
        return edKey(key);
    if (screen == MAKER_BROWSE)
        return brKey(key);
    if (makerRun.active && makerRun.testing &&
        (screen == PLAY || screen == PAUSE || screen == COMPLETE) &&
        (key == VK_F5 || key == VK_TAB)) {
        makerExitPlay();
        return true;
    }
    return false;
}

// Held Ctrl+Z / Ctrl+Y keep stepping through history like other editors; held arrows keep moving
// through the course list.
void makerKeyRepeat(int key) {
    if (screen == MAKER_EDIT && mkKeyDown(VK_CONTROL) && (key == 'Z' || key == 'Y'))
        edKey(key);
    if (screen == MAKER_BROWSE && (key == VK_LEFT || key == VK_RIGHT || key == VK_UP ||
                                   key == VK_DOWN || key == VK_PRIOR || key == VK_NEXT))
        brKey(key);
}

void makerChar(int ch) {
    if (screen == MAKER_EDIT)
        edChar(ch);
}

bool makerPointerMove(float x, float y) {
    if (screen == MAKER_EDIT)
        edMouseMove(x, y);
    else if (screen == MAKER_BROWSE)
        brMouseMove(x, y);
    else
        return false;
    return true;
}

bool makerPointerDown(float x, float y, int button) {
    if (screen == MAKER_EDIT)
        edMouseDown(x, y, button);
    else if (screen == MAKER_BROWSE)
        brMouseDown(x, y, button);
    else
        return false;
    return true;
}

bool makerPointerUp(float x, float y, int button) {
    if (screen == MAKER_EDIT)
        edMouseUp(x, y, button);
    else if (!makerScreen())
        return false;
    return true;
}

bool makerWheel(int delta) {
    if (screen == MAKER_EDIT)
        edWheel(delta);
    else if (screen == MAKER_BROWSE)
        brWheel(delta);
    else
        return false;
    return true;
}

void makerCaptureLost() {
    if (screen == MAKER_EDIT)
        makerEd.drag = DRAG_NONE;
}

void makerTick(float dt) {
    if (screen == MAKER_EDIT)
        edTick(dt);
    else if (screen == MAKER_BROWSE)
        brTick(dt);
}

void makerRender() {
    if (screen == MAKER_EDIT)
        edRender();
    else
        brRender();
}

// A small reminder during test play of the keys that return to the editor.
void makerRenderPlayOverlay() {
    if (!makerRun.active || !makerRun.testing || screen != PLAY || endingScene.active)
        return;
    const char *text = makerPlayFromCursor ? "TEST FROM CURSOR   F5 / Tab: back to the editor"
                                           : "TEST PLAY   F5 / Tab: back to the editor";
    float size = 8, w = mkTextWidth(text, size, true) + 14, h = 15;
    float x = (viewW - w) * 0.5f, y = 4;
    mkRect(x, y, w, h, 0x00000080);
    mkText(x + 7, y + (h - mkLineHeight(size, true)) * 0.5f, text, size, 0xffffffd0, true);
}

// Closing the window keeps unsaved editor work.
void makerShutdown() {
    if (makerEd.open && makerEd.dirty) {
        makerPrepareHeader(makerEd.level);
        makerSaveLevel(makerEd.slot, makerEd.level);
    }
}
