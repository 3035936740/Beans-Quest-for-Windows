#pragma once

// Custom-course run flags shared with campaign code. The maker implementation is included after
// interface.h; campaign paths only consult these flags and the forward-declared hooks.
struct MakerRunState {
    bool active;    // the running stage was baked from a custom course
    bool testing;   // launched from the editor; leaving the stage returns there
    bool verifying; // launched from the course start, so a clear verifies the course
    int slot;
    int recordJumps; // best clear used for the HUD jump target, 0 while uncleared
};

MakerRunState makerRun;

void makerLoadCurrentLevel();
void makerRecordClear();
void makerExitPlay();
void makerUnlock();
